 <!--<style>
	 /*  .dropdown1 {
   /*  float: left;
    overflow: hidden; */
}

.dropdown-content1 {
    display: none;
   /*  position: absolute; 
    background-color: #f9f9f9;*/
   /*  min-width: 160px; 
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);*/
    z-index: 1;
}
.dropdown-content1 a:hover {
   /*  background-color: #ddd; */
}
.dropdown1:hover .logo{
	 z-index: 0;
    opacity: 0;
	
}
.dropdown1:hover .dropdown-content1 {
    display: block;
} */ 
 </style>-->
  <!-- Header --> 
                <div class="container-fluid">   
				      
                    <div class="dropdown header-wrap clearfix">
                        <div class="logo-wrap">
                            <div id="logo" class="dropbtn logo">
                                <a href="index.php" rel="home" title="Red Salute">
                                    <img src="images/lion.png" alt="image" > 
                                </a>
                            </div><!-- /.logo -->
                        </div>
                        <div class="btn-menu"> 
                            <i class="ti-align-right"></i>
                        </div><!-- //mobile menu button --> 
                    
                        <div class="nav-flat-wrap dropdown-content1">
						
                            <div class="nav-wrap" style="width:100%;">                            
                                <nav id="mainnav" class=" mainnav">
                                    <ul class="menu"> 
                                        <li class=" has-mega-menu ">
                                            <a class="has-mega" href="index.php">Home</a> 
                                          
                                        </li>
                                        <li><a href="about.php">About Us</a>
                                            <ul class="submenu list-style">
                                                <li ><a href="about.php">About Us</a>
                                                   </li>
                                                <li><a href="team.php">Team</a></li>
                                                <li><a href="mission.php">Mission & Vision</a></li>
                                                <li><a href="data.php">Data security</a></li>
                                                <li><a href="whyresalute.php">Why LionBiz</a></li> 
                                                <li><a href="joinventer.php">Joint venture or partnership
</a></li>
                                            </ul>
                                        </li>
                                        <li><a href="service.php">Services</a>
                                            <ul class="submenu list-style"> 
											   <li><a href="customersupport.php">Customer support and call center</a></li>
											    <li><a href="socialmedia.php">Social media marketing services</a></li>
												<li><a href="softwaredevelopment.php">Software development services</a></li>
												 <li><a href="graphicdesign.php">Graphic and web design services</a></li>
												 <li><a href="procurement.php">Procurement Services</a></li>
												 <li><a href="dataentry.php">Data entry services</a></li>
                                                <li><a href="bookeeping.php">Bookkeeping and accounting</a></li>
                                               
                                                <li><a href="virtual.php">Virtual assistant services</a></li>
                                               <!-- <li><a href="outsourcing.php">Outsourcing service for Paraplanners and financial advisors</a></li>-->
                                                <li><a href="expnext.php">Expnext Implementation</a></li>
                                                 <li><a href="business.php">Business process outsourcing</a></li>
                                                <li><a href="ownoffice.php">Your own office in India</a></li>
                                                <li><a href="draft.php">Draftsman Services </a></li>
                                                
                                                <li><a href="product.php">Product / service Promotion</a></li>
                                               
                        
                                            </ul>
                                        </li>
                                        <!--<li><a href="">Portfolio</a> </li>-->
                                        <li><a href="career.php">Career</a>
											 <ul class="submenu list-style">
                                            <li ><a href="career.php">Current openings</a></li>
                                                <li><a href="whywork.php">Why work at Red Salute?</a></li>
												
                                            </ul>
											</a></li>
											</li>
                                        <li><a href="contact.php">Contact Us</a> </li>
                                                            
                                    </ul><!-- /.menu -->
                                </nav><!-- /.mainnav -->  
                            </div><!-- /.nav-wrap -->
                        </div>             
                    </div><!-- /.header-inner -->     
                </div>
          