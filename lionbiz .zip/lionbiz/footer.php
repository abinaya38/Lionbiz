<section class="flat-row section_carousel_metro2 ">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-section section-blog-title">
                            <h1 class="title fontsize36 fontweight600" style="text-align:center">Our Clients</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
					<div class="col-md-3">
					<div class="panel panel-default">
						
						<div class="panel-body two-col">
						<center>  <img src="images/client1.jpg" alt=""/> </center>
						</div>
						
					</div>
				</div>
		         <div class="col-md-3">
					<div class="panel panel-default">
						
						<div class="panel-body two-col">
						   <center>  <img src="images/client2.jpg" alt=""/> </center>
						</div>
						
					</div>
				</div>	
				 
				 <div class="col-md-3">
					<div class="panel panel-default">
						
						<div class="panel-body two-col">
						 <center>  <img src="images/client3.jpg" alt=""/> </center>
						</div>
						
					</div>
				</div>
				<div class="col-md-3">
					<div class="panel panel-default">
						
						<div class="panel-body two-col">
						 <center>  <img src="images/client4.jpg" alt=""/> </center>
						</div>
						
					</div>
				</div>
				
					
                    </div>
                </div>
            </div>
        </section> 


<style type="text/css">
.widget.widget_text.widget_info {
    margin-bottom: 51px;
}
@import '//codepen.io/chrisdothtml/pen/ojLzJK.css';
.social-btns .btn,
.social-btns .btn:before,
.social-btns .btn .fa {
  transition: all 0.35s;
  transition-timing-function: cubic-bezier(0.31, -0.105, 0.43, 1.59);
}
.social-btns .btn:before {
  top: 90%;
  left: -110%;
}
.social-btns .btn .fa {
  -webkit-transform: scale(0.8);
          transform: scale(0.8);
}
.social-btns .btn.facebook:before {
  background-color: #3b5998;
}
.social-btns .btn.facebook .fa {
  color: #3b5998;
}
.social-btns .btn.twitter:before {
  background-color: #3cf;
}
.social-btns .btn.twitter .fa {
  color: #3cf;
}
.social-btns .btn.google:before {
  background-color: #dc4a38;
}
.social-btns .btn.google .fa {
  color: #dc4a38;
}
.social-btns .btn.dribbble:before {
  background-color: #f26798;
}
.social-btns .btn.dribbble .fa {
  color: #f26798;
}
.social-btns .btn.skype:before {
  background-color: #00aff0;
}
.social-btns .btn.skype .fa {
  color: #00aff0;
}
.social-btns .btn:focus:before,
.social-btns .btn:hover:before {
  top: -10%;
  left: -10%;
}
.social-btns .btn:focus .fa,
.social-btns .btn:hover .fa {
  color: #fff;
  -webkit-transform: scale(1);
          transform: scale(1);
}
.social-btns {
  height: 50px;
  margin: auto;
  font-size: 0;
  text-align: center; 
 /*  position: absolute;*/
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin-bottom:20px
}
.social-btns .btn { 
  display: inline-block;
  background-color: #fff;
  width: 50px;
  height: 50px;
  line-height: 25px;
  margin: 0 10px;
  /* text-align: center; */
  position: relative;
  overflow: hidden;
  border-radius: 28%;
  box-shadow: 0 5px 15px -5px rgba(0,0,0,0.1);
  opacity: 0.99;
}
.social-btns .btn:before {
  content: '';
  width: 120%;
  height: 120%;
  position: absolute;
  -webkit-transform: rotate(45deg);
          transform: rotate(45deg);
}
.social-btns .btn .fa {
  font-size: 38px;
  vertical-align: middle;
}



.form-style-6{
    font: 95% Arial, Helvetica, sans-serif;
    /* max-width: 400px; */
    margin: 10px auto;
    padding: 16px;
    background: #535353;
}
.form-style-6 h1{
    background: #899491;
    padding: 0px 0;
    font-size: 140%;
    font-weight: 300;
    text-align: center;
    color: #fff;
    margin: -16px -16px 16px -16px;
}
.form-style-6 input[type="text"],
.form-style-6 input[type="date"],
.form-style-6 input[type="datetime"],
.form-style-6 input[type="email"],
.form-style-6 input[type="number"],
.form-style-6 input[type="search"],
.form-style-6 input[type="time"],
.form-style-6 input[type="url"],
.form-style-6 textarea,
.form-style-6 select 
{
    -webkit-transition: all 0.30s ease-in-out;
    -moz-transition: all 0.30s ease-in-out;
    -ms-transition: all 0.30s ease-in-out;
    -o-transition: all 0.30s ease-in-out;
    outline: none;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    background: #fff;
    margin-bottom: 4%;
    border: 1px solid #ccc;
    padding: 3%;
    color: #555;
    font: 95% Arial, Helvetica, sans-serif;
}
.form-style-6 input[type="text"]:focus,
.form-style-6 input[type="date"]:focus,
.form-style-6 input[type="datetime"]:focus,
.form-style-6 input[type="email"]:focus,
.form-style-6 input[type="number"]:focus,
.form-style-6 input[type="search"]:focus,
.form-style-6 input[type="time"]:focus,
.form-style-6 input[type="url"]:focus,
.form-style-6 textarea:focus,
.form-style-6 select:focus
{
    box-shadow: 0 0 5px #43D1AF;
    padding: 3%;
    border: 1px solid #43D1AF;
}

.form-style-6 input[type="submit"],
.form-style-6 input[type="button"]{
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    padding: 3%;
    background: #505050;
    border-bottom: 2px solid #505050;
    border-top-style: none;
    border-right-style: none;
    border-left-style: none;    
    color: #fff;
}
.form-style-6 input[type="submit"]:hover,
.form-style-6 input[type="button"]:hover{
    background: #2EBC99;
}
</style>
        <!-- Footer -->
        <footer class="footer">
            <div class="footer-widgets">
                <div class="container">
                    <div class="row"> 
                        <div class="col-md-3 col-sm-6 footer-reponsive">  
                            <div class="widget widget_text widget_info">
                                <h4 class="widget-title ">India</h4>
                                <ul class="flat-information">
                                    <li><b>Chemtech</b><br>
310, Nehru Palace Building,<br>
Bank junction, Aluva, Kerala.<br>
<i class="fa fa-volume-control-phone" ></i> <b> 0484 2985555</b></li>
                                </ul>
                            </div>      
                        </div>
						 <div class="col-md-3 col-sm-6 footer-reponsive">  
                            <div class="widget widget_text widget_info">
                                <h4 class="widget-title ">Qatar</h4>
                                <ul class="flat-information">
                                    <li><b>Chemtech</b><br>
12, Aziziya Commercial Building, <br>
Al Azizya, Doha.<br>
<i class="fa fa-volume-control-phone" ></i> <b> 974. 44.627.300</b></li>
                                </ul>
                            </div>      
                        </div>
						<div class="col-md-3 col-sm-6 footer-reponsive">  
                            <div class="widget widget_text widget_info">
                                <h4 class="widget-title ">UAE</h4>
                                <ul class="flat-information">
                                    <li><b>Chemtech</b><br>
21-10, Aspin Tower, <br>
Sheikh Zayed Road, Dubai.<br>
<i class="fa fa-volume-control-phone" ></i> <b> 00971.4.269 0770</b></li>
                                </ul>
                            </div>      
                        </div>
						<div class="col-md-3 col-sm-6 footer-reponsive">  
                            <div class="widget widget_text widget_info">
                                <h4 class="widget-title ">Oman</h4>
                                <ul class="flat-information">
                                    <li><b>LionBiz</b><br>
Plot No. 24, Block No. 252, Steet No.61,<br>
Ghala Industrial Area, Muscat.<br>
<i class="fa fa-volume-control-phone" ></i> <b>  968 2450 3385</b></li>
                                </ul>
                            </div>      
                        </div>
						

                        <!--<div class="col-md-4 col-sm-6 footer-reponsive">
                           <div class="form-style-6">
<h1>Quick Enquiry</h1>
<form method="POST">
<input type="text" name="name" placeholder="Your Name" />
<input type="email" name="email" placeholder="Email Address" />
<textarea name="message" placeholder="Type your Message"></textarea>
<input type="submit" value="Send" name="submit"/>
</form>
</div>
<?php 
/* if(isset($_POST['submit'])!=''){
				$name	=$_POST['name'];
				$email	=$_POST['email'];
				$message=$_POST['message'];
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				$headers .= "From:". $email. "\r\n";
				$email_to = "m8it0038@gmail.com";
				$subject = "Request A Free Consultation";
				$htmlContent = '<html>
				<head>
				<title></title>
				</head>
				<body>
				<p>Name:'.$name.'</p>
				<p>Email:'.$email.'</p>
				<p>Message:'.$message.'</p>
				</body>
				</html>';
				if(mail($email_to,$subject,$htmlContent,$headers))
				{						
					echo '<script type="text/javascript">alert("Submit Successfully");</script>';
					}else{ echo  '<script type="text/javascript"> alert("error");</script>';
				}
			} */
			

?>
						   
                        </div>-->

                       
                    </div>   
                </div><!-- /.container -->
			 <div class="container">
                    <div class="row"> 
					
                        <div class="col-md-12 footer-reponsive">	
<div class="social-btns"><a class="btn facebook" href="#"><i class="fa fa-facebook"></i></a><a class="btn twitter" href="#"><i class="fa fa-twitter"></i></a><a class="btn google" href="#"><i class="fa fa-google"></i></a><a class="btn dribbble" href="#"><i class="fa fa-dribbble"></i></a><a class="btn skype" href="#"><i class="fa fa-skype"></i></a>
</div>
				</div>
				</div>
				</div>
            </div><!-- /.footer-widgets -->
			
			
           <div class="header-footer">
                <div class="container">
                   <!-- <div class="row">
                        <div class="col-md-12">
                            <div class="wrap-footer margin-top-51 padding-top-62">
                                <div class="logo-footer float-left">
                                    <a href="#" title="Redsalute"><img src="images/lion.png" alt="image"></a>
                                </div>
                                <div class="nav-wrap float-left">                            
                                    <nav class="mainnav nav-footer">
                                        <ul class="menu"> 
                                            <li><a href="index.php">Home</a></li>
                                            <li><a href="about.php">About</a></li>
											  <li><a href="service.php">Services</a></li>
                                            <li><a href="career.php">Career</a></li>
                                            <li><a href="contact.php">Contact</a></li>                    
                                        </ul>
                                    </nav>
                                </div>
                               
                            </div>
                        </div>
                    </div>-->
                </div>
            </div>
        </footer>